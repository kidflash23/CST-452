Welcome to my application for Social Justice!!!
Ray Omoregie
GCU-451 Senior Project 2
